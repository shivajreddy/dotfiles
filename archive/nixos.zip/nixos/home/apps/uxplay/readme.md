1. Look at your obsidian notes.

but basically this script i found at https://taoa.io/posts/Setting-up-ipad-screen-mirroring-on-nixos
and he created this bash script to open and close ports.
because uxplay expects some ports to be open when it runs, but disable firewall overall is not secure, so this
script opens all the necessary ports AND closes them when uxplay ends.
