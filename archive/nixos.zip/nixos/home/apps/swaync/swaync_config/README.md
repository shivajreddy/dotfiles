![swaync](https://ik.imagekit.io/rayshold/dotfiles/_config/swaync/swaync.webp?updatedAt=1695677172526)

### Requirements

1. [adw-gtk3](https://github.com/lassekongo83/adw-gtk3)
