#!/usr/bin/env bash

sleep 0.1
swaync-client -t &
