return {
	"echasnovski/mini.comment",
	lazy = false,
	opts = {
		mappings = {
			comment = "<Leader>/",
			comment_visual = "<Leader>/",
			comment_line = "<Leader>/",
		},
	},
}
